//Step 5: import ViewEncapsulation from @angular/core
import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'my-app',
  template: `<div>
                <h1>Parent Component {{name}}</h1> 
                <child-comp></child-comp>   
             </div>`,
  styles: [`h1 { color: #F00;
                 font-family: Arial, sans-serif;}
          `]
  //Optional: add the external stylesheet 'messItUp.css'
  //styleUrls: ['messItUp.css'],
  //Step 6: add encapsulation property with value ViewEncapsulation.Native (native
  //Step 8: change value to .None
  //Step 9: change the value to .Emulated (the angular default value w/CSS encapsulation shim)
  //Step 10: set the encapsulation method in the child component and then revisit the ViewEncapsulation values here: None, Emulated and Native
})
export class AppComponent  { name = 'View Encapsulation'; }
