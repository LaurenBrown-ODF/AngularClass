import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'child-comp',
  template: `<div><h1>The Child Component</h1></div>`,
  styles: [`h1 { color: #00F;
                 font-family: Arial, sans-serif;}`],
           //Step 11: add :host css
           /* `:host {background-color: #E9DC51;
           width: 400px;
           height: 100px;
           display: flex;
           align-items: center;
           justify-content: center}`]*/

   //step 10: Add view encapsulation values below
   encapsulation: ViewEncapsulation.Emulated
})
export class ChildComponent  {  }
